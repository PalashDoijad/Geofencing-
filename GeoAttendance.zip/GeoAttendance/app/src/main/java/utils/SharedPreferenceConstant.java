package utils;

public class SharedPreferenceConstant {
	public static String SHARED_PREFERENCE_KEY = "geofence";
	//leo
	public static String INTOSCREEN="introscreen";

	public static String USERCODE="usercode";
	public static String VERIFICODE="verificode";
	public static String SIGNUPCODEAFTERVERFIFI="signupcode";
	public static String ACCESSTOKEN="accesstoken";
	public static String USERID="userid";
	public static String USERNAME="username";

	public static String PROFILEIMGPATH="profileimgpath";

	//login/logout setting
	public static String ABLETOGENERATECODE = "abletogeneratecode";
	public static String LOGIN_STATUS = "loginstatus";
	public static String CATEGORY="category";
	public static String SAVELOCATIONNAME="locationname";
	public static String JUMPTOBOOKINGLIST = "jumptobookinglist";
	public static String DEVICEID="deviceid";
    public static String LOCATIONSTRING="location";
    public static String SHOWSELETEDSERVCIE="selectedservice";
    public static String SHOWSELETEDSERVCIETOCALL="selectedservicecall";
    public static String STNTCT="ct";
    public static String APPOINMENTID="appoinid";
	public static String MAINCATEGORY="mainvategory";
    public static String GOOGLEANYMSG="googleanymsg";
	public static String INTROSHOWN = "shownintro";

	public static String PATHCATEGORY="category";
	public static String CATEGORYURL="categoryurl";






	public static String MYUID="myuid";
	public static String TODAYCLOCKUID="todayclockuid";
	public static String CLOCKONOFFDATE="clockonoffdate";




	public static String SHARED_PREFERENCE_KEY_CONTACT = "contact";
	public static String FRIENDUID = "frienduid";
}
