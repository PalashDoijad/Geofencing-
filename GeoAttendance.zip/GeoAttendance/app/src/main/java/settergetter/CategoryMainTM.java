package settergetter;

/**
 * Created by shail
 */

public class CategoryMainTM {


    public String getDesignation() {
        return Designation;
    }

    public void setDesignation(String designation) {
        Designation = designation;
    }

    private String Designation;







}
